# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(lodestar src/lodestar.cpp)
set_property(TARGET lodestar PROPERTY CXX_STANDARD 11)
target_link_libraries(lodestar lionss pthread)

add_executable(ZigbeeBind src/ZigbeeBind.cpp)
set_property(TARGET ZigbeeBind PROPERTY CXX_STANDARD 11)
target_link_libraries(ZigbeeBind lionss pthread)

add_executable(falseshare_pad src/falseshare_pad.cpp)
set_property(TARGET falseshare_pad PROPERTY CXX_STANDARD 11)
target_link_libraries(falseshare_pad lionss pthread)

add_executable(restic_prune src/restic_prune.cpp)
set_property(TARGET restic_prune PROPERTY CXX_STANDARD 11)
target_link_libraries(restic_prune lionss pthread)

add_executable(prop_shrink src/prop_shrink.cpp)
set_property(TARGET prop_shrink PROPERTY CXX_STANDARD 11)
target_link_libraries(prop_shrink lionss pthread)

add_executable(avx512_mask src/avx512_mask.cpp)
set_property(TARGET avx512_mask PROPERTY CXX_STANDARD 11)
target_link_libraries(avx512_mask lionss pthread)

add_executable(stm8_eeprom src/stm8_eeprom.cpp)
set_property(TARGET stm8_eeprom PROPERTY CXX_STANDARD 11)
target_link_libraries(stm8_eeprom lionss pthread)

add_executable(ElixirDialyzer src/ElixirDialyzer.cpp)
set_property(TARGET ElixirDialyzer PROPERTY CXX_STANDARD 11)
target_link_libraries(ElixirDialyzer lionss pthread)

add_executable(cgroupFreeze src/cgroupFreeze.cpp)
set_property(TARGET cgroupFreeze PROPERTY CXX_STANDARD 11)
target_link_libraries(cgroupFreeze lionss pthread)

add_executable(Pathfinder src/Pathfinder.cpp)
set_property(TARGET Pathfinder PROPERTY CXX_STANDARD 11)
target_link_libraries(Pathfinder lionss pthread)

add_executable(bleGattNotify src/bleGattNotify.cpp)
set_property(TARGET bleGattNotify PROPERTY CXX_STANDARD 11)
target_link_libraries(bleGattNotify lionss pthread)

add_executable(openapi_lint src/openapi_lint.cpp)
set_property(TARGET openapi_lint PROPERTY CXX_STANDARD 11)
target_link_libraries(openapi_lint lionss pthread)

add_executable(maroon src/maroon.cpp)
set_property(TARGET maroon PROPERTY CXX_STANDARD 11)
target_link_libraries(maroon lionss pthread)

add_executable(fft_bluestein src/fft_bluestein.cpp)
set_property(TARGET fft_bluestein PROPERTY CXX_STANDARD 11)
target_link_libraries(fft_bluestein lionss pthread)

add_executable(shadowCascade4 src/shadowCascade4.cpp)
set_property(TARGET shadowCascade4 PROPERTY CXX_STANDARD 11)
target_link_libraries(shadowCascade4 lionss pthread)

add_executable(undistortmap src/undistortmap.cpp)
set_property(TARGET undistortmap PROPERTY CXX_STANDARD 11)
target_link_libraries(undistortmap lionss pthread)

add_executable(hashAgg src/hashAgg.cpp)
set_property(TARGET hashAgg PROPERTY CXX_STANDARD 11)
target_link_libraries(hashAgg lionss pthread)

add_executable(btree-vacuum src/btree-vacuum.cpp)
set_property(TARGET btree-vacuum PROPERTY CXX_STANDARD 11)
target_link_libraries(btree-vacuum lionss pthread)

add_executable(hevc_tiles src/hevc_tiles.cpp)
set_property(TARGET hevc_tiles PROPERTY CXX_STANDARD 11)
target_link_libraries(hevc_tiles lionss pthread)

add_executable(marmot src/marmot.cpp)
set_property(TARGET marmot PROPERTY CXX_STANDARD 11)
target_link_libraries(marmot lionss pthread)

add_executable(flac_md5 src/flac_md5.cpp)
set_property(TARGET flac_md5 PROPERTY CXX_STANDARD 11)
target_link_libraries(flac_md5 lionss pthread)

add_executable(nightjar src/nightjar.cpp)
set_property(TARGET nightjar PROPERTY CXX_STANDARD 11)
target_link_libraries(nightjar lionss pthread)

add_executable(sack_reneg src/sack_reneg.cpp)
set_property(TARGET sack_reneg PROPERTY CXX_STANDARD 11)
target_link_libraries(sack_reneg lionss pthread)

add_executable(slatewing src/slatewing.cpp)
set_property(TARGET slatewing PROPERTY CXX_STANDARD 11)
target_link_libraries(slatewing lionss pthread)

add_executable(HelmholtzSolve src/HelmholtzSolve.cpp)
set_property(TARGET HelmholtzSolve PROPERTY CXX_STANDARD 11)
target_link_libraries(HelmholtzSolve lionss pthread)

add_executable(mtu_probe src/mtu_probe.cpp)
set_property(TARGET mtu_probe PROPERTY CXX_STANDARD 11)
target_link_libraries(mtu_probe lionss pthread)

add_executable(unwind-fp src/unwind-fp.cpp)
set_property(TARGET unwind-fp PROPERTY CXX_STANDARD 11)
target_link_libraries(unwind-fp lionss pthread)

add_executable(pic_leapfrog src/pic_leapfrog.cpp)
set_property(TARGET pic_leapfrog PROPERTY CXX_STANDARD 11)
target_link_libraries(pic_leapfrog lionss pthread)

add_executable(CronBackfill src/CronBackfill.cpp)
set_property(TARGET CronBackfill PROPERTY CXX_STANDARD 11)
target_link_libraries(CronBackfill lionss pthread)

add_executable(quartzvale src/quartzvale.cpp)
set_property(TARGET quartzvale PROPERTY CXX_STANDARD 11)
target_link_libraries(quartzvale lionss pthread)

