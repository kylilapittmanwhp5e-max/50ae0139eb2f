// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Measure false sharing"); }
int main(){
  announce();
  return lionss_run_workload("falseshare_pad");
}
